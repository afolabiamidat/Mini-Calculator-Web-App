# Mini Calculator Web App

A Pen created on CodePen.

Original URL: [https://codepen.io/Afolabi-Amidat-Fadekemi/pen/yyVvjXz](https://codepen.io/Afolabi-Amidat-Fadekemi/pen/yyVvjXz).

